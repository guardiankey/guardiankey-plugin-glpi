<?php
$LANG['guardiankeyauth']['title'] = "Autenticação GuardianKey";
