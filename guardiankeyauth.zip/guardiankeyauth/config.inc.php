<?php

//#define('GLPI_MODE', 'debug');
define('GLPI_DEMO_MODE', false);
